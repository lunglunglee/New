package com.ReSTAndroidTest;

import java.io.IOException;
import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ReSTAndroidTestActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView tview = new TextView(this);
        
        // For REST Authentication
        CredentialsProvider credProvider = new BasicCredentialsProvider();
        credProvider.setCredentials(new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT),
            new UsernamePasswordCredentials("kamal", "password"));
        
        DefaultHttpClient httpclient = new DefaultHttpClient();
        httpclient.setCredentialsProvider(credProvider);

        try
        {
			 // Call the REST service
        	 HttpGet request = new HttpGet("http://10.0.2.2:55786/ReSTStringUtilService.svc/count/asdf");
			 ResponseHandler<String> handler = new BasicResponseHandler();
			 String result = httpclient.execute(request, handler);
			 
			 // Parse xml		 
			 try {
			        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			        DocumentBuilder db = dbf.newDocumentBuilder();
			        InputSource is = new InputSource();
			        is.setCharacterStream(new StringReader(result));
			        Document doc = db.parse(is);
			        NodeList nodes = doc.getChildNodes();
			        Element line = (Element) nodes.item(0);
			     			        
			        // Display the result
			        tview.setText("String length: " + getCharacterData(line));
					setContentView(tview); 	
			    }
			    catch (Exception e) {
			        e.printStackTrace();
			    }			 		
		} 
		catch (ClientProtocolException e) {
			   e.printStackTrace();} 
		catch (IOException e) {
			   e.printStackTrace(); }
    }
    
     public static String getCharacterData(Element e) {
        Node child = e.getFirstChild();
        if (child instanceof CharacterData) {
           CharacterData cd = (CharacterData) child;
           return cd.getData();
        }
        return "?";
      }
}