﻿
#region Imports
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using System.Xml.Linq;
#endregion

namespace ReSTWP7Client
{
    public partial class MainPage : PhoneApplicationPage
    {
        #region Vars
        WebClient request;

        // TODO : Change the URL
        String serviceAddress = "http://localhost/ReSTStringUtilService/ReSTStringUtilService.svc/count/";
        #endregion

        #region Properties
        public String ServiceAddress
        {
            get { return serviceAddress; }           
        }
        #endregion

        public MainPage()
        {
            InitializeComponent();
            request = new WebClient();
            request.Credentials = new NetworkCredential("kamal", "password");
            request.DownloadStringCompleted += new DownloadStringCompletedEventHandler(request_DownloadStringCompleted);
            request.DownloadStringAsync(new Uri(ServiceAddress + txtInput.Text));
        }

        void request_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            // Parse the xml and get the result
            XDocument result = XDocument.Parse(e.Result);
            txtOutput.Text = "Count: " + result.Root.Value;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            // Call the ReST service
            if (!String.IsNullOrEmpty(txtInput.Text))
            {
                request.DownloadStringAsync(new Uri(serviceAddress + txtInput.Text));
            }
        }
    }
}